# Advisory Group Meeting notes

| **Important note** |
|:--|
| This group stopped working at the end of 2017 |

* [Meeting #1 (14.07.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_14.07.2017.md)
* [Meeting #2 (25.07.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_25.07.2017.md)
* [Meeting #3 (21.08.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_21.08.2017.md)
* [Meeting #4 (12.09.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_12.09.2017.md)
* [Meeting #5 (19.09.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_19.09.2017.md)
* [Meeting #6 (26.09.2017)](https://github.com/creativecommons/global-network-strategy/blob/master/advisory_group_meetings/advisory_group_meeting_26.09.2017.md)

