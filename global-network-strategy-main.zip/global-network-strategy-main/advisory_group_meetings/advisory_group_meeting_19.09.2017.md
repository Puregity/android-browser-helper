## 12.09.2017

**Reference documents**: 

* [Global Network Strategy](https://github.com/creativecommons/global-network-strategy/blob/master/GlobalNetworkStrategy-Final.md)

* [Meetings archive log](https://github.com/creativecommons/global-network-strategy#the-advisory-group-for-the-transition) 

**Participants** (include yourself below):
- Claudio
- Simeon
- Meredith
- Scann
- Mariana
- Soohyun
- Bilal 


**Notetaker**: Simeon

---

**Agenda / Notes**

* We have a timeline. We are opening the memberships and partnerships the 1st week of October. They will vouch the first round of applicants and then they will also approve members with the agreement of 5 of them. I will communicate with them.
	* Claudio is sending an email to Affiliates during the coming days giving them a notice regarding what will happen next 2 weeks in advance.
	* ACTIONS: (Mariana and SooHyun volunteer on this one)
		* Mini Guide for Vouching
		* Mini Guide for Approving
* Chapter Guidelines. We are reaching consensus and now the document will be reviewed by Diane.
	* ACTIONS:
		* 3 points brief to create a Chapter (Scann)
* Working Groups proposal by Meredith
	* On Diane’s hands.